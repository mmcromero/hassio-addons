"""Janela local do agente Avisaqui para vincular o computador via QR Code.

Nenhuma impressao e disparada por esta interface. API de pareamento pendente
de implementacao e revisao no servidor.
"""
import base64
from io import BytesIO
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk

from fluxo_pareamento import BASE, PairingFlow
from pareamento import PairingError, validate_url
from credenciais_windows import ProtectedStoreError

BG = '#101827'
FG = '#f1f5f9'
MUTED = '#a9b9d1'

def previous_origin():
    """Reaproveitar apenas URL legada, nunca copiar nem exibir token."""
    try:
        path = BASE / 'config.json'
        data = json.loads(path.read_text(encoding='utf-8'))
        return validate_url(data.get('url', ''))
    except (OSError, ValueError, TypeError, PairingError):
        return ''

class PairingWindow:
    def __init__(self, root):
        self.root = root
        self.root.title('Avisaqui — Vincular computador')
        self.root.geometry('560x610')
        self.root.minsize(450, 510)
        self.root.configure(bg=BG)
        self.flow = None
        self.events = queue.Queue()
        self.busy = False
        self.last_state = None
        self.qr_image = None
        self.origin = tk.StringVar(value=previous_origin())
        self.status_message = tk.StringVar(value='Informe o endereco HTTPS do Avisaqui.')
        self.code = tk.StringVar(value='—')
        self.setup()
        self.root.after(150, self.drain)
        self.root.after(5000, self.auto_check)

    def setup(self):
        container = tk.Frame(self.root, bg=BG, padx=26, pady=22)
        container.pack(fill='both', expand=True)
        tk.Label(container, text='Vincular computador', bg=BG, fg=FG,
                 font=('Segoe UI', 19, 'bold')).pack(anchor='w')
        tk.Label(container, text='Um gerente deve autorizar pelo proprio celular.',
                 bg=BG, fg=MUTED, font=('Segoe UI', 10)).pack(anchor='w', pady=(4, 18))
        tk.Label(container, text='Endereco HTTPS do Avisaqui', bg=BG, fg=FG).pack(anchor='w')
        self.url_entry = ttk.Entry(container, textvariable=self.origin, width=58)
        self.url_entry.pack(fill='x', pady=(5, 12))
        self.begin_button = ttk.Button(container, text='Criar pareamento', command=self.begin)
        self.begin_button.pack(fill='x')
        self.qr = tk.Label(container, bg='white', width=260, height=250, relief='flat')
        self.qr.pack(pady=(22, 7))
        tk.Label(container, text='Escaneie o QR Code com o celular do gerente',
                 bg=BG, fg=FG, font=('Segoe UI', 10)).pack()
        tk.Label(container, text='Alternativa: informe este codigo no painel do gerente',
                 bg=BG, fg=MUTED, font=('Segoe UI', 9)).pack(pady=(8, 3))
        tk.Label(container, textvariable=self.code, bg=BG, fg=FG,
                 font=('Segoe UI', 22, 'bold')).pack(pady=(0, 14))
        self.check_button = ttk.Button(container, text='Verificar autorizacao',
                                       command=self.check, state='disabled')
        self.check_button.pack(fill='x')
        tk.Label(container, textvariable=self.status_message, bg=BG, fg=MUTED,
                 wraplength=490, justify='left', font=('Segoe UI', 10)).pack(
                     anchor='w', pady=(15, 0))

    def submit(self, action, work):
        if self.busy:
            return
        self.busy = True
        self.begin_button.configure(state='disabled')
        self.check_button.configure(state='disabled')
        def job():
            try:
                self.events.put((action, work(), None))
            except (PairingError, ProtectedStoreError, OSError, ValueError) as exc:
                self.events.put((action, None, str(exc)))
            except Exception:
                # Nao divulgar respostas, traces ou segredos na UI.
                self.events.put((action, None, 'Falha inesperada. Consulte suporte.'))
        threading.Thread(target=job, daemon=True).start()

    def begin(self):
        try:
            url = validate_url(self.origin.get().strip())
            self.flow = PairingFlow(url)
        except (PairingError, ProtectedStoreError) as exc:
            self.status_message.set(str(exc))
            return
        self.status_message.set('Criando solicitacao segura...')
        if self.flow.is_linked():
            self.status_message.set('Este computador ja possui vinculo protegido.')
            return
        if self.flow.pending.exists() and self.last_state not in ('RECUSADO', 'EXPIRADO'):
            try:
                self.show_request(self.flow.resume())
                self.status_message.set('Solicitacao anterior recuperada. Verifique a autorizacao.')
                return
            except PairingError as exc:
                if 'expirada' not in str(exc):
                    self.status_message.set(str(exc))
                    return
            except (ProtectedStoreError, KeyError) as exc:
                self.status_message.set('Nao foi possivel recuperar solicitacao protegida. Consulte suporte.')
                return
        self.last_state = None
        self.submit('begin', self.flow.start)

    def show_request(self, info):
        try:
            import qrcode
            qr = qrcode.QRCode(box_size=5, border=2)
            qr.add_data(info['qr_url'])
            qr.make(fit=True)
            output = BytesIO()
            qr.make_image(fill_color='black', back_color='white').save(output, format='PNG')
            image = tk.PhotoImage(data=base64.b64encode(output.getvalue()).decode('ascii'))
            self.qr_image = image
            self.qr.configure(image=image, text='', width=260, height=250)
            self.code.set(info['code'])
            self.check_button.configure(state='normal')
        except ImportError:
            self.code.set(info['code'])
            self.status_message.set('QR indisponivel; use o codigo alternativo.')
            self.check_button.configure(state='normal')

    def check(self):
        if self.flow is None:
            return
        self.status_message.set('Consultando autorizacao...')
        self.submit('status', self.flow.status)

    def auto_check(self):
        # Aprovar no celular deve concluir o vinculo sem clique adicional no caixa.
        if self.flow is not None and not self.busy and self.code.get() != '—' and \
           self.last_state not in ('APROVADO', 'RECUSADO', 'EXPIRADO', 'RESGATADO'):
            self.check()
        self.root.after(5000, self.auto_check)

    def drain(self):
        try:
            while True:
                action, result, error = self.events.get_nowait()
                self.busy = False
                self.begin_button.configure(state='normal')
                if error:
                    self.status_message.set(error)
                    if self.code.get() != '—':
                        self.check_button.configure(state='normal')
                elif action == 'begin':
                    self.show_request(result)
                    self.begin_button.configure(text='Criar pareamento')
                    self.status_message.set('Aguardando confirmacao do gerente no celular.')
                elif action == 'status':
                    self.last_state = result
                    if result == 'APROVADO':
                        self.status_message.set('Autorizado. Protegendo credencial do computador...')
                        self.submit('redeem', self.flow.redeem)
                    elif result in ('RECUSADO', 'EXPIRADO'):
                        self.status_message.set('Solicitacao encerrada: ' + result.lower()
                            + '. Clique em gerar novo codigo.')
                        self.begin_button.configure(text='Gerar novo QR Code')
                    elif result == 'RESGATADO':
                        self.status_message.set('Resgate ja realizado. Verifique vinculo local.')
                    else:
                        self.status_message.set('Aguardando autorizacao do gerente.')
                        self.check_button.configure(state='normal')
                elif action == 'redeem':
                    self.code.set('—')
                    self.qr.configure(image='', text='')
                    self.qr_image = None
                    self.status_message.set('Computador vinculado. Reinicie o agente quando liberado.')
        except queue.Empty:
            pass
        self.root.after(150, self.drain)

def main():
    root = tk.Tk()
    PairingWindow(root)
    root.mainloop()

if __name__ == '__main__':
    main()
