"""Politica limitada de tentativas HTTP para a previa Windows pair-v1.

Nao muda IDs, nao apaga arquivos e nao solicita novos segredos.
Tempos em segundos; avancar so depois de falha transitoria.
"""
import time

DELAYS = (5, 10, 20, 40, 60)

class RetryWindow:
    def __init__(self, clock=None):
        self.clock = clock or time.monotonic
        self.failures = 0
        self.next_at = 0.0

    def reset(self):
        self.failures = 0
        self.next_at = 0.0

    def fail(self):
        delay = DELAYS[min(self.failures, len(DELAYS) - 1)]
        self.failures += 1
        self.next_at = self.clock() + delay
        return delay

    def ready(self):
        return self.clock() >= self.next_at
