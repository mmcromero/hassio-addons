"""Avisaqui: agente Windows de laboratorio. Captura TSPL -> OCR -> API -> KDS.
Nao encaminha PRN para impressora fisica. Nao bloqueia spooler.
"""
import argparse
from datetime import datetime, timezone
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import sqlite3
import subprocess
import tempfile
import time
import uuid
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from tspl_png import decode, png

BASE = Path.home() / 'Avisaqui_Agente'
CONFIG = BASE / 'config.json'
DATABASE = BASE / 'envios.sqlite3'
SOURCE = Path(r'C:\ProgramData\PagerVirtualLab\captura.prn')
MAX_BYTES = 20_000_000

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def validate_url(value):
    url = urlparse(value.rstrip('/'))
    if url.scheme != 'https' and not (url.scheme == 'http' and url.hostname in ('localhost','127.0.0.1')):
        raise ValueError('Use HTTPS (HTTP permitido somente em localhost)')
    if not url.netloc or url.username or url.password or url.query or url.fragment or url.path not in ('','/','/avisaqui','/avisaqui/'):
        raise ValueError('Informe a origem HTTPS, opcionalmente com /avisaqui/, sem credenciais')
    return value.rstrip('/')

def configure():
    BASE.mkdir(parents=True, exist_ok=True)
    print('Avisaqui - Configurar agente (credencial nao sera exibida)')
    url=validate_url(input('URL HTTPS do Avisaqui (pode incluir /avisaqui/): ').strip())
    key=getpass.getpass('Credencial criada no painel de impressao: ').strip()
    if not re.fullmatch(r'[a-f0-9]{64}',key):
        raise ValueError('Credencial deve ter 64 caracteres hexadecimais')
    temp=CONFIG.with_suffix('.tmp')
    temp.write_text(json.dumps({'url':url,'key':key}),encoding='utf-8')
    os.replace(temp,CONFIG)
    try: os.chmod(CONFIG,0o600)
    except OSError: pass
    print('Configuracao salva apenas no perfil local do Windows. Nao compartilhe esse arquivo.')
    return 0

def connect():
    BASE.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(DATABASE)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS eventos(
      id TEXT PRIMARY KEY, sha TEXT NOT NULL, numero INTEGER NOT NULL,
      estado TEXT NOT NULL, tentativas INTEGER NOT NULL DEFAULT 0,
      criado_em TEXT NOT NULL, mensagem TEXT NOT NULL DEFAULT ''
    )''')
    db.commit()
    return db

def extract_number(text):
    for line in text.splitlines():
        match=re.search(r'\b(?:PEDIDO|COMANDA|SENHA)\s*(?:N[Oº°.]*)?\s*[:#-]?\s*(\d{1,9})\b',line,re.IGNORECASE)
        if match:
            number=int(match.group(1))
            if number>0: return number
    raise ValueError('Numero de pedido nao identificado; nenhuma informacao enviada')

def capture(data):
    width,height,bitmap=decode(data)
    tesseract = shutil.which('tesseract')
    if not tesseract:
        candidate = Path(os.environ.get('ProgramFiles', r'C:\Program Files')) / 'Tesseract-OCR' / 'tesseract.exe'
        if candidate.is_file():
            tesseract = str(candidate)
    if not tesseract:
        raise RuntimeError('Tesseract nao encontrado no PATH ou em Program Files/Tesseract-OCR.')
    with tempfile.TemporaryDirectory(prefix='avisaqui-ocr-') as folder:
        filename=Path(folder)/'captura.png'
        filename.write_bytes(png(width,height,bitmap))
        commands=([tesseract,str(filename),'stdout','-l','por'],
                  [tesseract,str(filename),'stdout','-l','eng'])
        for command in commands:
            try:
                res=subprocess.run(command,capture_output=True,text=True,timeout=20)
            except FileNotFoundError:
                raise RuntimeError('Tesseract nao encontrado. Instale ou adicione ao PATH.')
            if res.returncode==0:
                try: return extract_number(res.stdout)
                except ValueError: pass
        raise ValueError('OCR nao identificou numero do pedido. Nao criar pedido por estimativa.')

def stable_read(source):
    if not source.is_file() or source.is_symlink():
        raise ValueError('Arquivo de captura nao encontrado ou link simbolico')
    before=source.stat()
    if not 0 < before.st_size <= MAX_BYTES: raise ValueError('Tamanho invalido')
    data=source.read_bytes()
    after=source.stat()
    if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns) or len(data)!=before.st_size:
        raise ValueError('Arquivo alterado durante leitura')
    return data

def queue(db,data):
    numero=capture(data)
    eid=uuid.uuid4().hex
    digest=hashlib.sha256(data).hexdigest()
    db.execute('INSERT INTO eventos(id,sha,numero,estado,criado_em) VALUES(?,?,?,?,?)',
               (eid,digest,numero,'PENDENTE',now()))
    db.commit()
    print(f'[{now()}] PEDIDO DETECTADO #{numero} | evento {eid[:10]} | aguardando servidor',flush=True)
    return eid

def publish_pending(db,config,tls_context):
    rows=db.execute("SELECT id,numero FROM eventos WHERE estado='PENDENTE' ORDER BY criado_em LIMIT 20").fetchall()
    for event_id,numero in rows:
        body=json.dumps({'evento_id':event_id,'numero':numero,'itens':[]}).encode('utf-8')
        req=Request(config['url']+'/api/integracoes/impressao/pedidos',body,
            {'Content-Type':'application/json','X-Avisaqui-Agent-Key':config['key']},method='POST')
        try:
            with urlopen(req,timeout=6,context=tls_context) as response:
                status=response.status
                response.read()
            if status in (200,201):
                db.execute("UPDATE eventos SET estado='CONFIRMADO',tentativas=tentativas+1,mensagem=? WHERE id=?",
                           (f'HTTP {status}',event_id))
                db.commit()
                print(f'[{now()}] KDS CONFIRMADO | pedido #{numero}',flush=True)
        except HTTPError as exc:
            if exc.code == 409:
                db.execute("UPDATE eventos SET estado='PENDENTE_DUPLICADO',tentativas=tentativas+1,mensagem='Numero ja ativo no servidor' WHERE id=?",(event_id,))
                db.commit()
                print(f'[{now()}] REVISAO NO PAINEL | numero #{numero} ja ativo',flush=True)
            elif exc.code in (400,401,403):
                db.execute("UPDATE eventos SET estado='ERRO_CONFIGURACAO',tentativas=tentativas+1,mensagem=? WHERE id=?",
                           (f'HTTP {exc.code}',event_id))
                db.commit()
                print(f'[{now()}] ERRO NA CONFIGURACAO | HTTP {exc.code}',flush=True)
            else:
                print(f'[{now()}] Servidor indisponivel (HTTP {exc.code}); pedido permanece na fila',flush=True)
                return
        except (OSError,URLError):
            print(f'[{now()}] Sem conexao. Pedido preservado localmente.',flush=True)
            return

def signature(path):
    try:
        s=path.stat()
        return (s.st_size,s.st_mtime_ns)
    except FileNotFoundError:
        return None

def run():
    # Usar o mesmo leitor protegido já testado: não ignorar uma identidade
    # pair-v1 pendente/corrompida e cair silenciosamente na chave legada.
    # O leitor mantém pair-v1 bloqueado no monitor até integração autorizada.
    from credencial_agente import load_agent_configuration
    cfg=load_agent_configuration(BASE, legacy_validate_url=validate_url)
    cfg['url']=validate_url(cfg['url'])
    if not re.fullmatch(r'[a-f0-9]{64}',cfg.get('key','')): raise ValueError('Credencial invalida')
    try:
        import truststore
    except ImportError as exc:
        raise RuntimeError('Dependencia ausente: instale com py -3 -m pip install --user truststore') from exc
    tls_context = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    db=connect()
    print('Avisaqui Windows -> API -> KDS | sem impressao fisica automatica')
    print('Arquivo antigo e referencia, nao vira pedido novo')
    baseline=signature(SOURCE);last=baseline;handled=baseline;stable=0;last_retry=0
    try:
        while True:
            current=signature(SOURCE)
            if current!=last:
                last=current;stable=0
            else:
                stable+=1
                if current and current!=handled and stable>=2:
                    try:
                        data=stable_read(SOURCE)
                        queue(db,data)
                        handled=current
                    except (ValueError,RuntimeError,OSError,sqlite3.Error) as exc:
                        print(f'[{now()}] CAPTURA INDISPONIVEL: {exc}',flush=True)
                        handled=current  # Evita loop de erros; nova impressao gera nova assinatura.
            if time.monotonic()-last_retry>=5:
                publish_pending(db,cfg,tls_context)
                last_retry=time.monotonic()
            time.sleep(.35)
    except KeyboardInterrupt:
        print('Monitor encerrado. Fila local preservada.')
    finally:
        db.close()
    return 0

def status():
    db=connect()
    for id,numero,estado,mensagem in db.execute('SELECT id,numero,estado,mensagem FROM eventos ORDER BY criado_em DESC LIMIT 30'):
        print(f'Pedido #{numero} | evento {id[:10]} | {estado} | {mensagem}')
    db.close()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--configurar',action='store_true')
    p.add_argument('--status',action='store_true')
    args=p.parse_args()
    try:
        if args.configurar:return configure()
        if args.status:return status()
        return run()
    except (ValueError,RuntimeError,OSError) as exc:
        print('ERRO:',exc)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
