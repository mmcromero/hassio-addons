"""Bloqueio interprocesso do journal pair-v1.

Usa bloqueio de byte do Windows (msvcrt) e libera automaticamente ao fechar
o processo, inclusive em encerramento abrupto. O arquivo nao contem segredos
nem deve ser apagado enquanto o agente estiver em uso.
"""
import contextlib
import errno
import os
from pathlib import Path
import sys
import time

LOCK_NAME = '.avisaqui-pair-v1.lock'
LOCK_TIMEOUT_SECONDS = 30
LOCK_POLL_SECONDS = 0.05


class PairProcessLockError(RuntimeError):
    pass


@contextlib.contextmanager
def journal_lock(base, timeout=LOCK_TIMEOUT_SECONDS):
    """Serializa processos que usam o mesmo diretorio DPAPI. Falha fechada."""
    directory = Path(base).resolve()
    try:
        directory.mkdir(parents=True, exist_ok=True)
        # Arquivo estavel; nunca remover: outra instancia pode estar aguardando.
        handle = open(directory / LOCK_NAME, 'a+b')
    except OSError as exc:
        raise PairProcessLockError('Nao foi possivel abrir o bloqueio do pareamento') from exc

    acquired = False
    try:
        deadline = time.monotonic() + timeout
        if sys.platform == 'win32':
            import msvcrt
            while True:
                try:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    acquired = True
                    break
                except OSError as exc:
                    if exc.errno not in (errno.EACCES, errno.EDEADLK, errno.EAGAIN):
                        raise PairProcessLockError('Bloqueio Windows indisponivel') from exc
                    if time.monotonic() >= deadline:
                        raise PairProcessLockError('Outro processo esta usando o pareamento') from exc
                    time.sleep(LOCK_POLL_SECONDS)
        else:
            # Suporte somente para testes automatizados em sistemas Unix.
            import fcntl
            while True:
                try:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                    break
                except BlockingIOError as exc:
                    if time.monotonic() >= deadline:
                        raise PairProcessLockError('Outro processo esta usando o pareamento') from exc
                    time.sleep(LOCK_POLL_SECONDS)
        yield
    finally:
        if acquired:
            if sys.platform == 'win32':
                import msvcrt
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()
