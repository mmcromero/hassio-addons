@echo off
cd /d "%~dp0"
py -3 agente.py --configurar
pause
