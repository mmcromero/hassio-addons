"""Fluxo de pareamento do caixa: orquestra cliente, DPAPI e retomada.

Nao inicia captura de impressao e nao altera a configuracao legada.
"""
import base64
from pathlib import Path
import re
import time

from pareamento import PairingClient, PairingError, generate_identity
from credenciais_windows import ProtectedStore, ProtectedStoreError

try:
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PrivateFormat, NoEncryption
    )
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
except ImportError:
    Ed25519PrivateKey = None

BASE = Path.home() / 'Avisaqui_Agente'

class PairingFlow:
    def __init__(self, origin, base=BASE, client=None, store_factory=ProtectedStore):
        self.client = client or PairingClient(origin)
        self.base = Path(base)
        self.pending = store_factory(self.base / 'pareamento.protected.json')
        self.active = store_factory(self.base / 'dispositivo.protected.json')

    def is_linked(self):
        if not self.active.exists():
            return False
        record = self.active.load()
        return record.get('kind') == 'device' and bool(record.get('credential'))

    def start(self):
        if self.active.exists():
            raise PairingError('Ja existe dispositivo vinculado. Nao substituir automaticamente.')
        if Ed25519PrivateKey is None:
            raise PairingError('Biblioteca cryptography ausente')
        private, public_pem = generate_identity()
        private_bytes = private.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())
        self.pending.save({'kind': 'starting', 'origin': self.client.origin,
                           'private_key': base64.b64encode(private_bytes).decode('ascii')})
        result = self.client.start(public_pem)
        # Persistir antes de exibir QR evita perda da prova de posse ao reiniciar.
        if not isinstance(result.get('expires_at'), int) or result['expires_at'] <= 0:
            raise PairingError('Servidor nao informou validade do pareamento')
        self.pending.save({'kind': 'pending', 'origin': self.client.origin,
                           'private_key': base64.b64encode(private_bytes).decode('ascii'),
                           'id': result['id'], 'challenge': result['challenge'],
                           'code': result['code'], 'qr_url': result['qr_url'],
                           'expires_at': result['expires_at']})
        return {'id': result['id'], 'code': result['code'],
                'qr_url': result['qr_url'], 'expires_at': result['expires_at']}

    def _load_pending(self):
        record = self.pending.load()
        if record.get('kind') != 'pending' or record.get('origin') != self.client.origin:
            raise PairingError('Solicitacao local nao recuperavel para este servidor')
        if Ed25519PrivateKey is None:
            raise PairingError('Biblioteca cryptography ausente')
        try:
            raw = base64.b64decode(record['private_key'], validate=True)
            if len(raw) != 32:
                raise ValueError()
            key = Ed25519PrivateKey.from_private_bytes(raw)
        except (KeyError, TypeError, ValueError) as exc:
            raise PairingError('Chave temporaria invalida') from exc
        return record, key

    def resume(self):
        record, _key = self._load_pending()
        if not isinstance(record.get('expires_at'), int) or record['expires_at'] <= int(time.time() * 1000):
            raise PairingError('Solicitacao expirada: gere um novo codigo')
        return {key: record[key] for key in ('id', 'code', 'qr_url', 'expires_at')}

    def status(self):
        record, key = self._load_pending()
        result = self.client.status(key, record['id'], record['challenge'])
        if not isinstance(result, dict) or result.get('state') not in (
                'PENDENTE', 'APROVADO', 'RECUSADO', 'EXPIRADO', 'RESGATADO'):
            raise PairingError('Estado de pareamento invalido')
        return result['state']

    def redeem(self):
        if self.active.exists():
            raise PairingError('Dispositivo ja possui credencial. Nao duplicar resgate.')
        record, key = self._load_pending()
        response = self.client.redeem(key, record['id'], record['challenge'])
        if not isinstance(response, dict):
            raise PairingError('Resposta de resgate invalida')
        credential = response.get('credential')
        device_id = response.get('dispositivo_id')
        restaurant_id = response.get('restaurante_id')
        if not isinstance(credential, str) or not re.fullmatch(r'[a-f0-9]{64}', credential) or \
           not isinstance(device_id, str) or not re.fullmatch(r'[a-fA-F0-9-]{36}', device_id) or \
           not isinstance(restaurant_id, str) or not restaurant_id or len(restaurant_id) > 128:
            raise PairingError('Credencial ou identidade invalida: nada foi salvo')
        self.active.save({'kind': 'device', 'origin': self.client.origin,
                          'credential': credential, 'dispositivo_id': device_id,
                          'restaurante_id': restaurant_id,
                          'caixa_nome': str(response.get('caixa_nome') or '')[:120]})
        # Nao apagar arquivo pendente automaticamente: auditavel se houve falha de rede.
        return {'dispositivo_id': device_id,
                'caixa_nome': str(response.get('caixa_nome') or '')[:120]}

    def display_state(self):
        if self.active.exists():
            self.active.load()
            return 'VINCULADO'
        if self.pending.exists():
            try:
                record = self.pending.load()
                return 'PENDENTE' if record.get('kind') == 'pending' else 'INCOMPLETO'
            except ProtectedStoreError:
                return 'ERRO_PROTECAO'
        return 'NAO_VINCULADO'
