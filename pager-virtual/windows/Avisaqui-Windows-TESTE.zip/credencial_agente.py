"""Leitura da identidade do agente Avisaqui, preservando modo legado.

Nunca migra ou apaga arquivos automaticamente. O caminho DPAPI tem prioridade.
"""
import json
from pathlib import Path
import re

from credenciais_windows import ProtectedStore, ProtectedStoreError
from pareamento import PairingError, validate_url

BASE = Path.home() / 'Avisaqui_Agente'
CREDENTIAL_PATTERN = re.compile(r'[a-f0-9]{64}\Z')

def load_agent_configuration(base=BASE, protector=None, legacy_validate_url=None):
    base = Path(base)
    device = base / 'dispositivo.protected.json'
    if device.exists() or device.is_symlink():
        secure = ProtectedStore(device, protector=protector)
        record = secure.load()  # Falha fechada: nunca usar legado se houver segredo protegido invalido.
        # Pair-v1 pertence ao protocolo de dispositivo novo. A fila legada ainda
        # usa chave/endpoint antigos e nao pode aproveitar essa identidade por
        # acidente, mesmo apos ACK. O desbloqueio exige integracao autorizada.
        if isinstance(record, dict) and record.get('protocol') == 'pair-v1':
            if record.get('ack_pending') is not False:
                raise ProtectedStoreError('Confirmacao pair-v1 pendente; monitor nao iniciado')
            raise ProtectedStoreError('Pair-v1 confirmado localmente, mas integracao do monitor ainda nao liberada')
        if record.get('kind') != 'device' or not CREDENTIAL_PATTERN.fullmatch(str(record.get('credential', ''))):
            raise ProtectedStoreError('Credencial vinculada invalida')
        if not isinstance(record.get('dispositivo_id'), str) or not record['dispositivo_id']:
            raise ProtectedStoreError('Identidade do dispositivo invalida')
        try:
            url = validate_url(record.get('origin'))
        except PairingError as exc:
            raise ProtectedStoreError('Origem do dispositivo invalida') from exc
        return {'url': url, 'key': record['credential'],
                'dispositivo_id': record['dispositivo_id'], 'modo': 'pareado'}

    config = base / 'config.json'
    if not config.is_file():
        raise ValueError('Computador nao vinculado: abra Avisaqui-Pareamento ou use configuracao legada')
    try:
        record = json.loads(config.read_text(encoding='utf-8'))
        url = (legacy_validate_url or validate_url)(record.get('url'))
    except (OSError, ValueError, TypeError, PairingError) as exc:
        raise ValueError('Configuracao legada invalida') from exc
    if not CREDENTIAL_PATTERN.fullmatch(str(record.get('key', ''))):
        raise ValueError('Credencial legada invalida')
    return {'url': url, 'key': record['key'], 'modo': 'legado'}
