"""Controlador independente da janela Tk para o pareamento pair-v1.

Apenas organiza o fluxo local. Nenhuma rotina de impressao e carregada.
"""
from cliente_pair_v1 import PairV1Error

TERMINAL = {'RECUSADO', 'EXPIRADO', 'CANCELADO'}

class PairV1Controller:
    def __init__(self, flow):
        self.flow = flow

    def open(self):
        """Reinicia de forma segura sem criar outra identidade."""
        if self.flow.active.exists():
            local = self.flow.inspect_active()
            if local.get('ack_pending'):
                return {'phase': 'ACK_PENDENTE', 'device_id': local.get('dispositivo_id')}
            return {'phase': 'VINCULADO_LOCAL', 'device_id': local.get('dispositivo_id')}
        state = self.flow.start_or_resume()
        if state['kind'] == 'terminal':
            return {'phase': state['terminal_state']}
        return {'phase': state['kind'], 'pairing_id': state['pairing_id'],
                'code': state['code'], 'qr_url': state['qr_url'],
                'expires_at': state['expires_at']}

    def update(self):
        """Consulta estado ou retoma entrega/confirmacao após reinício."""
        if self.flow.active.exists():
            local = self.flow.inspect_active()
            if local.get('ack_pending'):
                return self._ack()
            return {'phase': 'VINCULADO_LOCAL', 'device_id': local.get('dispositivo_id')}
        local = self.flow._record()
        if local.get('kind') == 'terminal':
            if local.get('terminal_state') not in TERMINAL:
                raise PairV1Error('Estado terminal protegido invalido')
            return {'phase': local['terminal_state']}
        if local.get('kind') == 'redeeming':
            return self._redeem()
        state = self.flow.status()
        if state in ('APROVADO', 'RESGATADO'):
            return self._redeem()
        if state in TERMINAL:
            self.flow.record_terminal(state)
            return {'phase': state}
        if state == 'CONFIRMADO':
            # Nunca afirmar vinculo se o Windows nao possui credencial DPAPI.
            raise PairV1Error('Servidor confirmou, mas nao existe credencial local; suporte necessario')
        return {'phase': 'PENDENTE'}

    def _redeem(self):
        result = self.flow.redeem_or_resume()
        return {'phase': result['state'], 'device_id': result['dispositivo_id']}

    def _ack(self):
        result = self.flow.confirm()
        return {'phase': result['state'], 'device_id': result['dispositivo_id']}
