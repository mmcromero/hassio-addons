"""Armazenamento de segredos do agente Avisaqui, isolado do monitor de impressao.

Escopo intencional: DPAPI do usuario atual (CurrentUser). Nao usa LocalMachine.
Falha em outras plataformas; nao existe fallback para texto puro.
"""
import base64
import json
import os
from pathlib import Path
import sys
import tempfile

MAX_SECRET_FILE = 16_384

class ProtectedStoreError(RuntimeError):
    pass

class WindowsDPAPI:
    """Criptografia nativa do Windows via pywin32, vinculada ao usuario atual."""
    def __init__(self):
        if sys.platform != 'win32':
            raise ProtectedStoreError('Protecao DPAPI disponivel somente no Windows')
        try:
            import win32crypt
            import win32cryptcon
        except ImportError as exc:
            raise ProtectedStoreError('Dependencia pywin32 ausente') from exc
        self.crypt = win32crypt
        self.flags = win32cryptcon.CRYPTPROTECT_UI_FORBIDDEN

    def protect(self, payload):
        if not isinstance(payload, bytes) or not payload:
            raise ProtectedStoreError('Segredo invalido')
        try:
            return self.crypt.CryptProtectData(payload, 'Avisaqui - agente Windows', None,
                                               None, None, self.flags)
        except Exception as exc:
            raise ProtectedStoreError('Falha na protecao local da credencial') from exc

    def unprotect(self, payload):
        try:
            _description, decoded = self.crypt.CryptUnprotectData(payload, None,
                                                                   None, None, self.flags)
            return decoded
        except Exception as exc:
            raise ProtectedStoreError('Credencial indisponivel para este usuario Windows') from exc

class ProtectedStore:
    """JSON envelope de bytes DPAPI, gravado atomicamente no perfil do usuario.

    O segredo DPAPI nao pode ser migrado automaticamente para outra conta Windows.
    A mesma instancia nao serve para um servico LocalSystem ou outro usuario.
    """
    def __init__(self, file_path, protector=None):
        self.path = Path(file_path)
        self.protector = protector if protector is not None else WindowsDPAPI()

    def save(self, record):
        if not isinstance(record, dict) or not record:
            raise ProtectedStoreError('Registro protegido invalido')
        if not all(isinstance(k, str) and isinstance(v, (str, int, bool)) for k, v in record.items()):
            raise ProtectedStoreError('Campos protegidos invalidos')
        plain = json.dumps(record, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        if len(plain) > 8192:
            raise ProtectedStoreError('Registro excede limite')
        cipher = self.protector.protect(plain)
        wrapper = json.dumps({'version': 1, 'scope': 'windows-current-user',
                              'protected': base64.b64encode(cipher).decode('ascii')},
                             separators=(',', ':')).encode('utf-8')
        if len(wrapper) > MAX_SECRET_FILE:
            raise ProtectedStoreError('Arquivo protegido excede limite')
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        tmp_path = None
        try:
            # Nunca escrever dados em claro no disco, inclusive arquivos temporarios.
            with tempfile.NamedTemporaryFile(mode='wb', prefix='.avisaqui-', suffix='.tmp',
                                             dir=str(self.path.parent), delete=False) as stream:
                tmp_path = Path(stream.name)
                stream.write(wrapper)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp_path, self.path)
        finally:
            if tmp_path is not None and tmp_path.exists():
                tmp_path.unlink()

    def load(self):
        if not self.path.is_file() or self.path.is_symlink():
            raise ProtectedStoreError('Arquivo protegido nao encontrado')
        if self.path.stat().st_size > MAX_SECRET_FILE:
            raise ProtectedStoreError('Arquivo protegido excede limite')
        try:
            outer = json.loads(self.path.read_bytes())
            if outer.get('version') != 1 or outer.get('scope') != 'windows-current-user':
                raise ProtectedStoreError('Formato protegido nao reconhecido')
            cipher = base64.b64decode(outer['protected'], validate=True)
            record = json.loads(self.protector.unprotect(cipher))
            if not isinstance(record, dict):
                raise ProtectedStoreError('Conteudo protegido invalido')
            return record
        except ProtectedStoreError:
            raise
        except (ValueError, TypeError, KeyError, OSError) as exc:
            raise ProtectedStoreError('Arquivo protegido corrompido ou inacessivel') from exc

    def exists(self):
        return self.path.is_file()
