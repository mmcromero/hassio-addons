@echo off
cd /d "%~dp0"
py -3 janela_pair_v1.py
pause
