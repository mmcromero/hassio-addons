@echo off
cd /d "%~dp0"
py -3 -m pip install cryptography pywin32 truststore "qrcode[pil]"
pause
