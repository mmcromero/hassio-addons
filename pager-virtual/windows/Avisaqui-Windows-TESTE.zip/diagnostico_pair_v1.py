"""Diagnostico local somente leitura para a previa pair-v1.

Nenhuma rede, captura, driver, spooler ou escrita de arquivo.
Nunca exibe usuario Windows, chaves, tokens, QR ou IDs completos.
"""
import base64
import binascii
import importlib.util
import re
import uuid
from urllib.parse import urlparse, parse_qsl
from pathlib import Path
import sys

from credenciais_windows import WindowsDPAPI, ProtectedStore, ProtectedStoreError
from fluxo_pair_v1 import DEFAULT_BASE



def _uuid_ok(value):
    """Verifica formato UUID sem gravar ou divulgar o identificador."""
    if not isinstance(value, str):
        return False
    try:
        return str(uuid.UUID(value)) == value
    except (ValueError, AttributeError):
        return False


def _key_ok(value):
    """A chave privada do protocolo deve conter 32 bytes em base64 estrito."""
    if not isinstance(value, str):
        return False
    try:
        return len(base64.b64decode(value, validate=True)) == 32
    except (ValueError, binascii.Error):
        return False


def _qr_ok(value, origin, pairing_id):
    if not isinstance(value, str) or len(value) > 2048:
        return False
    try:
        url = urlparse(value)
        target = urlparse(origin)
        query = parse_qsl(url.query, keep_blank_values=True, strict_parsing=True,
                          max_num_fields=2)
    except ValueError:
        # URL com host/IPv6 malformado: nao interromper diagnostico somente leitura.
        return False
    return (url.scheme == 'https' and url.netloc == target.netloc
            and not url.username and not url.password and not url.fragment
            and url.path == target.path.rstrip('/') + '/autorizar'
            and query == [('solicitacao', pairing_id)])


def _pairing_state(record, origin):
    """Confere a estrutura local do journal sem usar rede nem ler segredos em logs."""
    kind = record.get('kind')
    if kind not in ('starting', 'pending', 'redeeming', 'terminal'):
        return 'INVALIDO'
    if not _uuid_ok(record.get('client_request_id')):
        return 'INVALIDO'
    if not all(_key_ok(record.get(k)) for k in ('signing_private', 'delivery_private')):
        return 'INVALIDO'
    if kind == 'starting':
        return 'CRIACAO_PENDENTE'
    if (not _uuid_ok(record.get('pairing_id'))
            or not isinstance(record.get('code'), str)
            or re.fullmatch(r'[0-9]{8}', record['code']) is None
            or type(record.get('expires_at')) is not int
            or record['expires_at'] < 1
            or not _qr_ok(record.get('qr_url'), origin, record['pairing_id'])):
        return 'INVALIDO'
    if kind == 'redeeming':
        if not all(_uuid_ok(record.get(k)) for k in
                   ('redeem_operation_id', 'ack_operation_id')):
            return 'INVALIDO'
        return 'RESGATE_PENDENTE'
    if kind == 'terminal':
        if record.get('terminal_state') not in ('RECUSADO', 'EXPIRADO', 'CANCELADO'):
            return 'INVALIDO'
        return 'ENCERRADO'
    return 'AGUARDANDO_APROVACAO'


def diagnose(base=DEFAULT_BASE, platform=None, protector_factory=WindowsDPAPI,
             store_factory=ProtectedStore, module_available=None):
    """Devolve somente estados seguros para apresentar na interface."""
    platform = sys.platform if platform is None else platform
    base = Path(base)
    report = {
        'platform': 'OK' if platform == 'win32' else 'REQUER_WINDOWS',
        'dependencies': 'OK',
        'dpapi': 'NAO_TESTADO',
        'pairing': 'NENHUM',
        'device': 'NENHUM',
        'ready': False,
    }
    available = module_available or (lambda name: importlib.util.find_spec(name) is not None)
    if not all(available(module) for module in ('cryptography', 'truststore', 'qrcode', 'PIL')):
        report['dependencies'] = 'INCOMPLETAS'
    if report['platform'] != 'OK':
        return report
    try:
        protector = protector_factory()
        probe = b'avisaqui-pair-v1-dpapi-readiness'
        if protector.unprotect(protector.protect(probe)) != probe:
            raise ProtectedStoreError('DPAPI inconsistente')
        report['dpapi'] = 'OK'
    except (ProtectedStoreError, OSError, RuntimeError):
        report['dpapi'] = 'INDISPONIVEL'
        return report

    # Metadados usados somente para validar consistencia entre journals.
    # Nunca sao incluidos no retorno, UI ou logs.
    origins = {}
    pairing_ids = {}
    for key, filename in (
        ('pairing', 'pareamento-v1.protected.json'),
        ('device', 'dispositivo.protected.json'),
    ):
        path = base / filename
        if path.is_symlink():
            report[key] = 'INVALIDO'
            continue
        if not path.exists():
            continue
        try:
            record = store_factory(path, protector=protector).load()
            if not isinstance(record, dict):
                report[key] = 'INVALIDO'
                continue
            if record.get('protocol') != 'pair-v1':
                report[key] = 'OUTRO_PROTOCOLO'
                continue
            # O journal deve ter a mesma origem HTTPS estrita usada pelo cliente.
            # Não exibir URL, IDs, codigo de 8 digitos ou credenciais.
            from cliente_pair_v1 import validate_origin, PairV1Error
            try:
                origin = validate_origin(record.get('origin'))
            except (PairV1Error, ValueError, TypeError):
                report[key] = 'INVALIDO'
                continue
            origins[key] = origin
            if key == 'pairing':
                report[key] = _pairing_state(record, origin)
                if report[key] in ('AGUARDANDO_APROVACAO', 'RESGATE_PENDENTE', 'ENCERRADO'):
                    pairing_ids[key] = record['pairing_id']
            elif record.get('kind') == 'device':
                # Reutilizar a validacao integral do fluxo em vez de declarar
                # prontidao apenas pelo campo ack_pending. Sem rede ou gravacao.
                from fluxo_pair_v1 import PairV1Flow
                try:
                    PairV1Flow._valid_active(record, origin)
                except PairV1Error:
                    report[key] = 'INVALIDO'
                    continue
                report[key] = ('ACK_PENDENTE' if record['ack_pending']
                               else 'CONFIRMADO_LOCAL')
                # O validador de identidade real exige UUID; stubs antigos
                # podem omitir este metadado, sem criar um ID ficticio.
                if _uuid_ok(record.get('pairing_id')):
                    pairing_ids[key] = record['pairing_id']
            else:
                report[key] = 'INVALIDO'
        except (ProtectedStoreError, OSError, ValueError, TypeError, KeyError):
            report[key] = 'INACESSIVEL'
    if len(origins) == 2 and origins['pairing'] != origins['device']:
        # Nao inferir prontidao quando arquivo de solicitacao e dispositivo
        # pertencem a origens HTTPS divergentes.
        report['pairing'] = 'ORIGENS_DIVERGENTES'
        report['device'] = 'ORIGENS_DIVERGENTES'
    if (len(pairing_ids) == 2 and pairing_ids['pairing'] != pairing_ids['device']
            and report['pairing'] not in ('ORIGENS_DIVERGENTES',)
            and report['device'] not in ('ORIGENS_DIVERGENTES',)):
        # Mesmo servidor nao implica mesma solicitacao: falhar fechado.
        report['pairing'] = 'VINCULOS_DIVERGENTES'
        report['device'] = 'VINCULOS_DIVERGENTES'
    report['ready'] = (report['dependencies'] == 'OK' and report['dpapi'] == 'OK'
                       and report['pairing'] in ('NENHUM', 'CRIACAO_PENDENTE',
                                                'AGUARDANDO_APROVACAO', 'RESGATE_PENDENTE', 'ENCERRADO')
                       and report['device'] in ('NENHUM', 'ACK_PENDENTE', 'CONFIRMADO_LOCAL'))
    return report


def format_diagnostic(report):
    """Resultado minimo, sem secretos e sem inferir autorizacao comercial."""
    return ('Windows: {platform} | Dependencias: {dependencies} | DPAPI: {dpapi} | '
            'Solicitacao: {pairing} | Dispositivo: {device}. '
            'Diagnostico local: {ready}. Nao comprova acesso a API, '
            'autorizacao comercial ou impressao.').format(
                **{**report, 'ready': 'APTO' if report['ready'] else 'PENDENTE'})
