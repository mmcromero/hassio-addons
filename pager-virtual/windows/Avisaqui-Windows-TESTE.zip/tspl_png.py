"""Conversor TSPL BITMAP -> PNG. Sem acesso a impressoras. Lab Coibeu, modo testado."""
import re
import struct
import zlib

def decode(data):
    matches = list(re.finditer(rb'BITMAP\s+(\d+),(\d+),(\d+),(\d+),(\d+),', data))
    if len(matches) != 1:
        raise ValueError('Formato desconhecido: esperado um BITMAP TSPL')
    m = matches[0]
    x,y,row,height,mode = map(int,m.groups())
    if (x,y,mode)!=(0,0,1) or not (1<=row<=4096 and 1<=height<=10000):
        raise ValueError('Parametros BITMAP nao homologados')
    start=m.end()
    length=row*height
    payload=data[start:start+length]
    if len(payload)!=length or not re.fullmatch(rb'\s*PRINT\s+\d+,\d+\s*',data[start+length:]):
        raise ValueError('PRN incompleto ou trailer inesperado')
    return row*8,height,payload

def png(width,height,bitmap):
    def chunk(tag,data):
        return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
    row=width//8
    raw=bytearray()
    for y in range(height):
        raw.append(0)
        for byte in bitmap[y*row:(y+1)*row]:
            for bit in range(7,-1,-1):
                raw.append(255 if byte & (1<<bit) else 0)
    return (b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,0,0,0,0))+
        chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b''))
