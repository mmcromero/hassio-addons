"""Orquestrador local pair-v1 com journal DPAPI.

Nao manipula impressao. Estados locais sao isolados da fila SQLite do agente.
Nao permite downgrade silencioso para o protocolo antigo.
"""
import base64
import re
import threading
from functools import wraps
from pathlib import Path
import uuid

from pair_v1 import (PROTOCOL, new_keys, private_raw, restore_keys, ProtocolError, require_uuid)
from cliente_pair_v1 import PairV1Client, PairV1Error
from credenciais_windows import ProtectedStore, ProtectedStoreError
from lock_pair_v1 import journal_lock

DEFAULT_BASE = Path.home() / 'Avisaqui_Agente'

# Protege threads e instancias no mesmo processo; journal_lock protege outros
# processos Windows. Um contador por thread evita bloquear o mesmo processo
# novamente quando redeem_or_resume chama confirm. Estado permanece no DPAPI.
_LOCKS_GUARD = threading.Lock()
_LOCKS = {}
_THREAD_LOCKS = threading.local()


def _serialized(method):
    @wraps(method)
    def run(self, *args, **kwargs):
        key = str(self.base.resolve())
        with _LOCKS_GUARD:
            lock = _LOCKS.setdefault(key, threading.RLock())
        with lock:
            held = getattr(_THREAD_LOCKS, 'held', None)
            if held is None:
                held = set()
                _THREAD_LOCKS.held = held
            if key in held:
                return method(self, *args, **kwargs)
            with journal_lock(self.base):
                held.add(key)
                try:
                    return method(self, *args, **kwargs)
                finally:
                    held.remove(key)
    return run


class PairV1Flow:
    def __init__(self, origin, base=DEFAULT_BASE, client=None, store_factory=ProtectedStore):
        self.client = client or PairV1Client(origin)
        self.base = Path(base)
        self.pending = store_factory(self.base / 'pareamento-v1.protected.json')
        self.active = store_factory(self.base / 'dispositivo.protected.json')

    @staticmethod
    def _valid_active(record, origin):
        """Nao considerar qualquer arquivo DPAPI como identidade valida."""
        if not isinstance(record, dict) or record.get('kind') != 'device' or (
                record.get('protocol') != PROTOCOL or record.get('origin') != origin):
            raise PairV1Error('Identidade protegida incompativel com este servidor')
        for field in ('dispositivo_id', 'pairing_id', 'redeem_operation_id', 'ack_operation_id'):
            try:
                require_uuid(record.get(field))
            except ProtocolError as exc:
                raise PairV1Error('Identificadores protegidos invalidos') from exc
        if not isinstance(record.get('credential'), str) or not re.fullmatch(
                r'[a-f0-9]{64}', record['credential']):
            raise PairV1Error('Credencial protegida invalida')
        restaurant = record.get('restaurante_id')
        if not isinstance(restaurant, str) or not (1 <= len(restaurant) <= 128):
            raise PairV1Error('Restaurante protegido invalido')
        if type(record.get('ack_pending')) is not bool:
            raise PairV1Error('Estado de confirmacao invalido')
        if record['ack_pending']:
            for field in ('signing_private', 'delivery_private'):
                if not isinstance(record.get(field), str):
                    raise PairV1Error('Chaves de confirmacao protegidas ausentes')
        return record

    def inspect_active(self):
        if not self.active.exists():
            raise PairV1Error('Nao existe dispositivo protegido')
        return self._valid_active(self.active.load(), self.client.origin)

    def _record(self):
        record = self.pending.load()
        if not isinstance(record, dict):
            raise PairV1Error('Solicitacao protegida invalida')
        if record.get('protocol') != PROTOCOL or record.get('origin') != self.client.origin:
            raise PairV1Error('Pareamento protegido incompativel com este servidor')
        return record

    def _keys(self, record):
        try:
            return restore_keys(base64.b64decode(record['signing_private'], validate=True),
                                base64.b64decode(record['delivery_private'], validate=True))
        except (KeyError, ValueError, TypeError) as exc:
            raise PairV1Error('Chaves protegidas invalidas') from exc

    @_serialized
    def start_or_resume(self):
        if self.active.exists():
            self.inspect_active()
            raise PairV1Error('Dispositivo ja possui identidade; nao criar novo vinculo')
        if self.pending.exists():
            record = self._record()
        else:
            signer, delivery = new_keys()
            record = {
                'protocol': PROTOCOL, 'origin': self.client.origin,
                'kind': 'starting', 'client_request_id': str(uuid.uuid4()),
                'signing_private': base64.b64encode(private_raw(signer)).decode('ascii'),
                'delivery_private': base64.b64encode(private_raw(delivery)).decode('ascii')
            }
            self.pending.save(record)  # grava chaves antes de enviar o primeiro POST
        # O identificador idempotente de criacao nunca deve ser trocado em retry.
        try:
            require_uuid(record.get('client_request_id'))
        except ProtocolError as exc:
            raise PairV1Error('Identificador de criacao protegido invalido') from exc
        if record.get('kind') == 'terminal':
            if record.get('terminal_state') not in ('RECUSADO', 'EXPIRADO', 'CANCELADO'):
                raise PairV1Error('Estado terminal protegido invalido')
            return {'kind': 'terminal', 'terminal_state': record['terminal_state']}
        if record.get('kind') in ('pending', 'redeeming', 'delivered'):
            if record['kind'] == 'delivered':
                raise PairV1Error('Entrega antiga nao suportada sem credencial local')
            try:
                require_uuid(record.get('pairing_id'))
                if record['kind'] == 'redeeming':
                    require_uuid(record.get('redeem_operation_id'))
                    require_uuid(record.get('ack_operation_id'))
            except ProtocolError as exc:
                raise PairV1Error('Operacao de pareamento protegida invalida') from exc
            if not isinstance(record.get('code'), str) or not re.fullmatch(
                    r'[0-9]{8}', record['code']) or not isinstance(record.get('qr_url'), str) or (
                    not isinstance(record.get('expires_at'), int)):
                raise PairV1Error('Solicitacao protegida incompleta')
            return self._summary(record)
        if record['kind'] != 'starting':
            raise PairV1Error('Estado local invalido')
        signer, delivery = self._keys(record)
        info = self.client.create(record['client_request_id'], signer, delivery)
        record.update({
            'kind': 'pending', 'pairing_id': info['id'], 'code': info['code'],
            'qr_url': info['qr_url'], 'expires_at': info['expires_at']
        })
        self.pending.save(record)
        return self._summary(record)

    @staticmethod
    def _summary(record):
        return {field: record.get(field) for field in ('kind', 'pairing_id', 'code', 'qr_url', 'expires_at')}

    @_serialized
    def record_terminal(self, state):
        """Preserva a negativa do servidor; nao apaga chaves nem cria outro pedido."""
        if state not in ('RECUSADO', 'EXPIRADO', 'CANCELADO'):
            raise PairV1Error('Estado terminal desconhecido')
        if self.active.exists():
            self.inspect_active()
            raise PairV1Error('Dispositivo ja protegido; nao encerrar pareamento')
        record = self._record()
        if record.get('kind') == 'terminal':
            if record.get('terminal_state') != state:
                raise PairV1Error('Conflito com estado terminal protegido')
            return
        if record.get('kind') not in ('pending', 'redeeming'):
            raise PairV1Error('Solicitacao sem estado terminal valido')
        record['kind'] = 'terminal'
        record['terminal_state'] = state
        self.pending.save(record)

    @_serialized
    def status(self):
        record = self._record()
        if record.get('kind') not in ('pending', 'redeeming'):
            raise PairV1Error('Solicitacao nao ativa')
        signer, _ = self._keys(record)
        return self.client.status(signer, record['pairing_id'], str(uuid.uuid4()))['state']

    @_serialized
    def redeem_or_resume(self):
        if self.active.exists():
            self.inspect_active()
            return self.confirm()  # nunca pede outra credencial apos persistir
        record = self._record()
        if record.get('kind') not in ('pending', 'redeeming'):
            raise PairV1Error('Pareamento sem autorizacao ou estado incorreto')
        signer, delivery = self._keys(record)
        if record.get('redeem_operation_id'):
            try:
                require_uuid(record['redeem_operation_id'])
                require_uuid(record.get('ack_operation_id'))
            except ProtocolError as exc:
                raise PairV1Error('Identificadores de resgate protegidos invalidos') from exc
        if not record.get('redeem_operation_id'):
            record['redeem_operation_id'] = str(uuid.uuid4())
            record['ack_operation_id'] = str(uuid.uuid4())
            record['kind'] = 'redeeming'
            self.pending.save(record)  # registra operacao antes de solicitar resgate
        payload = self.client.redeem(signer, delivery, record['pairing_id'],
                                     record['redeem_operation_id'])
        active = {
            'protocol': PROTOCOL, 'kind': 'device', 'origin': self.client.origin,
            'dispositivo_id': payload['dispositivo_id'], 'restaurante_id': payload['restaurante_id'],
            'caixa_nome': payload['caixa_nome'], 'credential': payload['credential'],
            'pairing_id': record['pairing_id'],
            'redeem_operation_id': record['redeem_operation_id'],
            'ack_operation_id': record['ack_operation_id'],
            'signing_private': record['signing_private'], 'delivery_private': record['delivery_private'],
            'ack_pending': True
        }
        self.active.save(active)  # DPAPI persistido ANTES do ACK
        return self.confirm()

    @_serialized
    def confirm(self):
        if not self.active.exists():
            raise PairV1Error('Nao ha credencial local protegida para confirmar')
        record = self.inspect_active()
        if not record.get('ack_pending'):
            return {'state': 'CONFIRMADO', 'dispositivo_id': record['dispositivo_id']}
        try:
            signer, _delivery = self._keys(record)
            result = self.client.ack(signer, record['pairing_id'], record['redeem_operation_id'],
                                     record['ack_operation_id'])
        except (KeyError, ValueError, TypeError) as exc:
            raise PairV1Error('Confirmacao local invalida') from exc
        if result['dispositivo_id'] != record['dispositivo_id']:
            raise PairV1Error('Dispositivo confirmado difere do vinculo salvo')
        record['ack_pending'] = False
        # A chave de entrega nao e mais necessaria depois do ACK; reduzir exposicao.
        record.pop('delivery_private', None)
        record.pop('signing_private', None)
        self.active.save(record)
        return {'state': 'CONFIRMADO', 'dispositivo_id': record['dispositivo_id']}
