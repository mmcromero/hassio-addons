"""Avisaqui Windows: cliente de pareamento isolado do monitor de impressão.

Contrato preliminar; a API de servidor ainda não está implementada.
"""
import base64
import json
import re
import ssl
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError

DOMAIN = b'avisaqui-pair-proof-v1\n'
MAX_RESPONSE = 16_384

class PairingError(Exception):
    pass

def generate_identity():
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    except ImportError as exc:
        raise PairingError('Biblioteca cryptography ausente') from exc
    private = Ed25519PrivateKey.generate()
    public = private.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo).decode('ascii')
    return private, public

def proof(private, pairing_id, challenge, purpose='redeem'):
    if not isinstance(pairing_id, str) or not re.fullmatch(r'[a-fA-F0-9-]{36}', pairing_id):
        raise PairingError('ID de pareamento inválido')
    if not isinstance(challenge, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', challenge):
        raise PairingError('Desafio inválido')
    if purpose not in ('status', 'redeem'):
        raise PairingError('Operacao de prova invalida')
    data = DOMAIN + purpose.encode('ascii') + b'\n' + pairing_id.encode('ascii') + b'\n' + challenge.encode('ascii')
    return base64.urlsafe_b64encode(private.sign(data)).rstrip(b'=').decode('ascii')

def validate_url(origin):
    if not isinstance(origin, str):
        raise PairingError('Origem inválida')
    p = urlparse(origin)
    if p.scheme != 'https' or not p.hostname or p.username or p.password or p.query or p.fragment \
       or p.path not in ('', '/', '/avisaqui', '/avisaqui/'):
        raise PairingError('Informe a URL HTTPS do Avisaqui')
    return origin.rstrip('/')

class PairingClient:
    def __init__(self, origin, transport=None):
        self.origin = validate_url(origin)
        self.transport = transport or self._request

    @staticmethod
    def _request(url, method, data, headers=None):
        try:
            import truststore
        except ImportError as exc:
            raise PairingError('Biblioteca truststore ausente') from exc
        body = json.dumps(data).encode('utf-8') if data is not None else None
        request = Request(url, data=body, headers={'Accept': 'application/json',
            'Content-Type': 'application/json', **(headers or {})}, method=method)
        try:
            with urlopen(request, timeout=8, context=truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)) as resp:
                if resp.status not in (200, 201):
                    raise PairingError('Resposta HTTP inesperada')
                payload = resp.read(MAX_RESPONSE + 1)
                if len(payload) > MAX_RESPONSE:
                    raise PairingError('Resposta muito grande')
                return json.loads(payload)
        except HTTPError as exc:
            raise PairingError(f'Servidor recusou a requisição (HTTP {exc.code})') from exc
        except (OSError, ValueError) as exc:
            raise PairingError('Falha de conexão ou resposta inválida') from exc

    def start(self, public_key):
        result = self.transport(self.origin + '/api/agentes/pareamentos',
                                'POST', {'public_key': public_key}, None)
        if not isinstance(result, dict):
            raise PairingError('Resposta de início inválida')
        pairing_id, challenge = result.get('id'), result.get('challenge')
        if not isinstance(pairing_id, str) or not re.fullmatch(r'[a-fA-F0-9-]{36}', pairing_id) \
           or not isinstance(challenge, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', challenge) \
           or not isinstance(result.get('code'), str) or not re.fullmatch(r'\d{8}', result['code']) \
           or not isinstance(result.get('qr_url'), str) or len(result['qr_url']) > 2048:
            raise PairingError('Dados de início inválidos')
        qr = urlparse(result['qr_url'])
        source = urlparse(self.origin)
        if qr.scheme != 'https' or qr.netloc != source.netloc or qr.username or qr.password:
            raise PairingError('QR Code com destino não autorizado')
        return result

    def status(self, private, pairing_id, challenge):
        signature = proof(private, pairing_id, challenge, 'status')
        return self.transport(self.origin + '/api/agentes/pareamentos/' + pairing_id + '/estado',
                              'GET', None, {'X-Avisaqui-Pair-Proof': signature})

    def redeem(self, private, pairing_id, challenge):
        signature = proof(private, pairing_id, challenge)
        return self.transport(self.origin + '/api/agentes/pareamentos/' + pairing_id + '/resgatar',
                              'POST', {'signature': signature}, None)
