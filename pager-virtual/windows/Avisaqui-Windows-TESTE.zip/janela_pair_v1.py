"""Janela de pre-visualizacao do agente Avisaqui: somente protocolo pair-v1.

NÃO configura impressora, NÃO aciona spooler, NÃO inicia captura de pedidos.
Ainda depende do backend pair-v1 e da revisão independente de Segurança.
"""
import base64
from io import BytesIO
import json
from pathlib import Path
import queue
import threading
import tkinter as tk
from tkinter import ttk

from cliente_pair_v1 import PairV1Error, validate_origin
from credenciais_windows import ProtectedStore, ProtectedStoreError
from fluxo_pair_v1 import DEFAULT_BASE, PairV1Flow
from interface_pair_v1 import PairV1Controller
from retry_pair_v1 import RetryWindow
from diagnostico_pair_v1 import diagnose, format_diagnostic

BG = '#101827'
FG = '#f1f5f9'
MUTED = '#b1c0d7'
POLL_MS = 5000
LOCAL_COMPLETE = {'CONFIRMADO', 'VINCULADO_LOCAL'}
TERMINAL = {'RECUSADO', 'EXPIRADO', 'CANCELADO'}

def protected_origin(base=DEFAULT_BASE, store_factory=ProtectedStore):
    """Retoma a origem do journal DPAPI existente; sem criar nova solicitacao.

    None indica ausencia de journal. String vazia indica journal inacessivel:
    nunca cair silenciosamente para a URL legada nesses casos.
    """
    for name in ('dispositivo.protected.json', 'pareamento-v1.protected.json'):
        path = Path(base) / name
        if path.is_symlink():
            return ''
        if not path.exists():
            continue
        try:
            record = store_factory(path).load()
            if not isinstance(record, dict) or record.get('protocol') != 'pair-v1':
                return ''
            return validate_origin(record.get('origin'))
        except (ProtectedStoreError, OSError, ValueError, TypeError, PairV1Error):
            return ''
    return None


def previous_origin():
    """Prioriza o journal protegido; legado apenas sugere endereco, nunca token."""
    saved = protected_origin()
    if saved is not None:
        return saved
    try:
        record = json.loads((DEFAULT_BASE / 'config.json').read_text(encoding='utf-8'))
        return validate_origin(record.get('url'))
    except (OSError, ValueError, TypeError, PairV1Error):
        return ''

class PairV1Window:
    def __init__(self, root, controller_factory=None):
        self.root = root
        self.root.title('Avisaqui — Vincular computador (previa pair-v1)')
        self.root.geometry('570x730')
        self.root.minsize(465, 650)
        self.root.configure(bg=BG)
        self.controller_factory = controller_factory or self._factory
        self.controller = None
        self.events = queue.Queue()
        self.retry = RetryWindow()
        self.busy = False
        self.phase = 'INICIAL'
        self.qr_image = None
        self.origin = tk.StringVar(value=previous_origin())
        self.code = tk.StringVar(value='—')
        self.manager_url = tk.StringVar(value='')
        self.status_text = tk.StringVar(value='Informe a URL HTTPS do Avisaqui.')
        self._setup()
        self.root.after(150, self._drain)
        self.root.after(POLL_MS, self._poll)
        # Retoma somente quando ha journal DPAPI valido; nunca cria novo
        # pareamento automaticamente a partir da configuracao legada.
        saved_origin = protected_origin()
        if saved_origin and self.origin.get() == saved_origin:
            self.root.after(300, self.start)

    @staticmethod
    def _factory(origin):
        return PairV1Controller(PairV1Flow(origin))

    def _setup(self):
        base = tk.Frame(self.root, bg=BG, padx=24, pady=18)
        base.pack(fill='both', expand=True)
        tk.Label(base, text='Vincular computador', bg=BG, fg=FG,
                 font=('Segoe UI', 19, 'bold')).pack(anchor='w')
        tk.Label(base, text='O gerente autoriza pelo celular, sem login no caixa.',
                 bg=BG, fg=MUTED, font=('Segoe UI', 10)).pack(anchor='w', pady=(5, 15))
        tk.Label(base, text='URL HTTPS do Avisaqui', bg=BG, fg=FG).pack(anchor='w')
        ttk.Entry(base, textvariable=self.origin).pack(fill='x', pady=(5, 12))
        self.start_button = ttk.Button(base, text='Iniciar ou retomar pareamento',
                                       command=self.start)
        self.start_button.pack(fill='x')
        self.diagnostic_button = ttk.Button(base, text='Verificar este Windows (sem conexao)',
                                            command=self.diagnostic)
        self.diagnostic_button.pack(fill='x', pady=(6, 0))
        self.qr = tk.Label(base, bg='white', relief='flat')
        self.qr.pack(pady=(18, 9))
        tk.Label(base, text='Escaneie no celular do gerente', bg=BG, fg=FG,
                 font=('Segoe UI', 10)).pack()
        tk.Label(base, text='Ou use o codigo alternativo na pagina do gerente',
                 bg=BG, fg=MUTED, font=('Segoe UI', 9)).pack(pady=(8, 2))
        tk.Label(base, textvariable=self.code, bg=BG, fg=FG,
                 font=('Segoe UI', 22, 'bold')).pack(pady=(0, 14))
        tk.Label(base, text='Link para o celular (alternativa ao QR):',
                 bg=BG, fg=FG).pack(anchor='w')
        ttk.Entry(base, textvariable=self.manager_url, state='readonly').pack(fill='x', pady=(3, 6))
        self.copy_link_button = ttk.Button(base, text='Copiar link para o gerente',
                                           command=self.copy_manager_link, state='disabled')
        self.copy_link_button.pack(fill='x', pady=(0, 7))
        self.check_button = ttk.Button(base, text='Verificar agora', command=self.check,
                                        state='disabled')
        self.check_button.pack(fill='x')
        tk.Label(base, textvariable=self.status_text, bg=BG, fg=MUTED,
                 wraplength=490, justify='left', font=('Segoe UI', 10)).pack(
                     anchor='w', pady=(18, 0))
        tk.Label(base, text='PREVIA DE DESENVOLVIMENTO — nao usar em caixa comercial',
                 bg=BG, fg='#fbbf24', font=('Segoe UI', 9, 'bold')).pack(
                     side='bottom', anchor='w', pady=(12, 0))

    def _submit(self, action, work):
        if self.busy:
            return
        self.busy = True
        self.start_button.configure(state='disabled')
        self.check_button.configure(state='disabled')
        def job():
            try:
                self.events.put((action, work(), None, False))
            except PairV1Error as exc:
                self.events.put((action, None, str(exc), exc.transient))
            except (ProtectedStoreError, OSError, ValueError) as exc:
                self.events.put((action, None, str(exc), False))
            except Exception:
                # Nao mostrar token, resposta HTTP ou stack trace na janela.
                self.events.put((action, None, 'Falha inesperada. Consulte o suporte.', False))
        threading.Thread(target=job, daemon=True).start()

    def start(self):
        if self.phase in TERMINAL or self.busy:
            return
        try:
            origin = validate_origin(self.origin.get().strip())
            self.controller = self.controller_factory(origin)
        except (PairV1Error, ProtectedStoreError) as exc:
            self.status_text.set(str(exc))
            return
        self.retry.reset()
        self.phase = 'ABRINDO'
        self.status_text.set('Recuperando ou criando a solicitacao protegida...')
        self._submit('open', self.controller.open)

    def diagnostic(self):
        if self.busy:
            return
        self.status_text.set('Verificando ambiente local, sem rede ou impressao...')
        self._submit('diagnostic', diagnose)

    def copy_manager_link(self):
        url = self.manager_url.get()
        if not url:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(url)
        self.status_text.set('Link do gerente copiado. Confirme o codigo no Windows antes de aprovar.')

    def _set_qr(self, url, code):
        self.code.set(code)
        self.manager_url.set(url)
        self.copy_link_button.configure(state='normal')
        try:
            import qrcode
            image = qrcode.make(url).convert('RGB')
            image.thumbnail((225, 225))
            output = BytesIO()
            image.save(output, format='PNG')
            self.qr_image = tk.PhotoImage(data=base64.b64encode(output.getvalue()).decode('ascii'))
            self.qr.configure(image=self.qr_image, text='')
        except (ImportError, OSError, ValueError):
            self.qr_image = None
            self.qr.configure(image='', text='QR indisponivel. Use o codigo.')
            self.status_text.set('QR indisponivel; use o codigo no painel do gerente.')

    def _clear_qr(self):
        self.manager_url.set('')
        self.copy_link_button.configure(state='disabled')
        self.qr_image = None
        self.qr.configure(image='', text='')
        self.code.set('—')

    def check(self):
        if self.controller is None or self.busy or self.phase in LOCAL_COMPLETE | TERMINAL:
            return
        self.status_text.set('Consultando autorizacao...')
        self._submit('update', self.controller.update)

    def _poll(self):
        if self.controller is not None and not self.busy and self.retry.ready():
            if self.phase == 'RETRY_OPEN':
                # Mesmo controller e journal DPAPI: idempotencia na retomada.
                self._submit('open', self.controller.open)
            elif self.phase in ('pending', 'redeeming', 'ACK_PENDENTE', 'PENDENTE',
                                'APROVADO', 'RESGATADO'):
                self.check()
        self.root.after(POLL_MS, self._poll)

    def _handle(self, data):
        phase = data.get('phase')
        self.phase = phase
        if phase in ('pending', 'redeeming'):
            code, url = data.get('code'), data.get('qr_url')
            if code and url:
                self._set_qr(url, code)
            self.status_text.set(
                'Solicitacao em andamento. Aguardando gerente ou recuperacao segura...')
            self.check_button.configure(state='normal')
        elif phase == 'ACK_PENDENTE':
            self._clear_qr()
            self.status_text.set('Credencial ja foi protegida. Confirmando recebimento...')
            self.check_button.configure(state='normal')
            self.root.after(300, self.check)
        elif phase == 'VINCULADO_LOCAL':
            self._clear_qr()
            self.status_text.set('Identidade local armazenada. Status online nao verificado.')
        elif phase == 'PENDENTE':
            self.status_text.set('Aguardando aprovacao do gerente no celular...')
            self.check_button.configure(state='normal')
        elif phase in ('CONFIRMADO',):
            self._clear_qr()
            self.status_text.set('Vinculo confirmado. O agente de impressao nao foi iniciado.')
        elif phase in TERMINAL:
            self.retry.reset()
            self._clear_qr()
            self.start_button.configure(state='disabled')
            self.check_button.configure(state='disabled')
            self.status_text.set('Solicitacao ' + phase.lower() +
                                 '. Nao apague dados protegidos; aguarde fluxo de renovacao.')
        else:
            self.status_text.set('Estado inesperado; nao concluir vinculo.')

    def _drain(self):
        try:
            while True:
                action, result, error, transient = self.events.get_nowait()
                self.busy = False
                self.start_button.configure(state='normal')
                if error:
                    if transient:
                        delay = self.retry.fail()
                        if action == 'open':
                            self.phase = 'RETRY_OPEN'
                        self.status_text.set(
                            'Servidor indisponivel. Tentativa automatica em ate %d segundos. '
                            'A solicitacao e as chaves protegidas serao mantidas.' % (
                                delay + POLL_MS // 1000))
                    else:
                        self.phase = 'ERROR_PAUSED'
                        self.status_text.set(error + '. Tentativa automatica pausada.')
                    if self.controller is not None and action != 'open':
                        self.check_button.configure(state='normal')
                elif action == 'diagnostic' and isinstance(result, dict):
                    if self.phase in ('pending', 'redeeming', 'ACK_PENDENTE',
                                      'PENDENTE', 'APROVADO', 'RESGATADO'):
                        self.check_button.configure(state='normal')
                    self.status_text.set(format_diagnostic(result))
                elif isinstance(result, dict):
                    self.retry.reset()
                    self._handle(result)
                else:
                    self.status_text.set('Resposta local invalida.')
        except queue.Empty:
            pass
        self.root.after(150, self._drain)

def main():
    root = tk.Tk()
    PairV1Window(root)
    root.mainloop()

if __name__ == '__main__':
    main()
